安装根目录必须直接包含 runtime、backend 和安装清单；例如 E:\uma\MaaUma-基础版-0.4.3-windows-x64，不是它外面的 E:\uma。以下示例路径请替换为实际安装根。

# MaaUma 客户端存储审计（默认只列清单）

这份工具用于**已安装的普通客户端**，不用于开发仓库。必须显式指定 `--app-root`；安装目录需有 MaaUma 包标记，源码 `.git`／`.worktrees` 根及链接目录会拒绝。

在目标电脑解压本工具的同一目录中运行（路径换成那台电脑的实际客户端）：

```powershell
& 'E:\uma\runtime\python.exe' -B -X utf8 .\audit_client_storage.py --app-root 'E:\uma' --report 'E:\maauma-storage-audit.json'
```

默认 `dry_run=true`，不删除任何缓存，只在指定 `--report` 位置保存审计结果。不要把本机开发仓库的 `E:\uma` 误当成另一台电脑的客户端；缺安装标记或检测到源码根即停止。

若还不知道 64GB 来自哪个目录，可加 `--measure`。它只读取文件大小，按更新缓存、Pacer运行记录、日志、根目录下载ZIP等汇总，不读取截图内容，不跟随目录链接。`logical_size_measurement.incomplete=true` 表示达到时间预算，只测到了部分数据。

清单只针对同一安装的 `updates/suite-staged/<32位哈希目录>`：

- 当前 `maauma-suite-state.json` 指向的 stage 及回退备份始终保留。
- 当前／未来 prepared 更新、运行中的 helper／下载 owner、未完成／失败安装事务、链接、未知文件和没有明确所有权的损坏下载均保留。
- 可候选的有旧成功更新、版本已被当前成功安装取代且尚未应用的 prepared，以及 ZIP 内标记能证明是旧版本的完整旧下载。
- 新版写有 `download.json` 的未 prepared 下载，只有标记与本 stage 对应且 owner 已明确退出后才可回收；活跃／查询不确定的 owner 保留。这与已形成 ticket 的待安装更新不同。
- **不删除 `pacer/backend/runs`，不删除配置、账号、种马库、复盘、任何运行账本或当前状态。**

只有人工看完 JSON 清单、确认目标目录和保留项后，才可另行明确使用 `--apply`。它仍只处理清单规则确认的旧更新缓存；不清 Pacer 历史。

```powershell
& 'E:\uma\runtime\python.exe' -B -X utf8 .\audit_client_storage.py --app-root 'E:\uma' --report 'E:\maauma-storage-cleanup.json' --apply
```

`candidate_logical_bytes`／`removed_bytes` 是文件逻辑长度，**不代表实际释放空间**；硬链接、簇分配及其他程序写入都会造成差异。工具不关闭程序、不停止 helper、不操作模拟器、不联网、不上传报告。若达到时间预算，`budget_exhausted=true`，可在检查后另行重跑，当前保留项不会因超时被放宽。

`storage_maintenance.py` 与主脚本必须放在一起。工具复用客户端已有的标准库更新模块，不需要安装新依赖。
