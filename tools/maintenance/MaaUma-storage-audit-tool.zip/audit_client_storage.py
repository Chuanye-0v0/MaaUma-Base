"""Default dry-run. Explicitly target one installed MaaUma client, never a repo."""
import argparse,importlib,importlib.util,json,math,os,stat,sys,time
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--app-root',type=Path,required=True)
parser.add_argument('--report',type=Path,default=Path('maauma-storage-audit.json'))
parser.add_argument('--apply',action='store_true',help='Execute only the proven obsolete updater cache cleanup.')
parser.add_argument('--max-seconds',type=float,default=30)
parser.add_argument('--measure',action='store_true',help='Also measure logical category sizes, without following links.')
args=parser.parse_args();root=args.app_root.absolute();here=Path(__file__).resolve().parent
if not math.isfinite(args.max_seconds)or args.max_seconds<=0:parser.error('max-seconds必须为正有限秒数。')
if not root.is_dir()or(root/'.git').exists()or(root/'.worktrees').exists():parser.error('请指定客户端安装目录，不接受源码仓库或工作树根。')
for path in (root,*root.parents):
 info=path.lstat()
 if stat.S_ISLNK(info.st_mode)or getattr(info,'st_file_attributes',0)&0x400:parser.error('安装路径包含链接或重解析目录，未执行清理。')
if not any((root/n).is_file()for n in ('public-package-manifest.json','product-package-manifest.json')):parser.error('未找到客户端安装标记，未执行清理。')
sys.path.insert(0,str(root/'backend'))
try:import desktop
except ImportError:parser.error('客户端后台文件不完整，无法审计；没有删除任何缓存。')
module_path=here/'storage_maintenance.py'
if not module_path.is_file():parser.error('缺少同一审计包中的 storage_maintenance.py。')
spec=importlib.util.spec_from_file_location('desktop.maauma_storage_audit',module_path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.cleanup_staged_updates(root,dry_run=not args.apply,max_seconds=args.max_seconds)
result.update(app_root=str(root),explicit_apply=args.apply,
 protected_data=['当前回退stage','当前/未来prepared更新','运行中的helper或下载owner','未完成/失败安装事务','无明确所有权的损坏下载','config','全部Pacer运行/复盘/种马库/账号数据'],
 candidate_logical_bytes=sum(row['bytes']for row in result.get('candidates',[])),
 note='所有bytes是文件逻辑长度估计，不是磁盘实际释放量；默认只生成清单。')
if args.measure:
    sizes={};deadline=time.monotonic()+args.max_seconds;incomplete=False;errors=0
    for directory,subdirs,files in os.walk(root,followlinks=False):
        parent=Path(directory);safe=[]
        if time.monotonic()>deadline:incomplete=True;break
        for name in subdirs:
            try:
                info=(parent/name).lstat()
                if not(stat.S_ISLNK(info.st_mode)or getattr(info,'st_file_attributes',0)&0x400):safe.append(name)
            except OSError:errors+=1
        subdirs[:]=safe
        for name in files:
            try:
                p=parent/name;info=p.lstat()
                if not stat.S_ISREG(info.st_mode)or getattr(info,'st_file_attributes',0)&0x400:continue
                rel=p.relative_to(root);parts=rel.parts
                category=('suite_update_cache'if parts[:2]==('updates','suite-staged')else
                          'pacer_run_records'if parts[:3]==('pacer','backend','runs')else
                          'root_downloaded_zips'if len(parts)==1 and p.suffix.lower()=='.zip'else
                          parts[0]if parts[0]in {'updates','logs','debug','exports','review_exports'}else'program_and_other')
                row=sizes.setdefault(category,{'logical_bytes':0,'files':0});row['logical_bytes']+=info.st_size;row['files']+=1
            except OSError:errors+=1
    result['logical_size_measurement']={'categories':sizes,'incomplete':incomplete,'errors':errors,'follows_links':False}
args.report.absolute().write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'dry_run':not args.apply,'candidates':len(result.get('candidates',[])),
 'candidate_logical_bytes':result['candidate_logical_bytes'],'removed_stages':result['removed_stages'],
 'report':str(args.report.absolute()),'budget_exhausted':result['budget_exhausted']},ensure_ascii=False))
